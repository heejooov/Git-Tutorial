package com.example.myapplication

data class ServiceModel (
    var servId: String?,
    var servNm: String?,
    var jurMnofNm: String?,
    var servDgst: String?,
    var tgtrDtlCn: String?,
    var slctCritCn: String?,
    var alwServCn: String?,
    var servSeCode: String?
)